function [ConTest, ConRetest,ConMean,ConConjunct] = MainStreamCon(Dat1,Dat2)

s3=size(Dat1,3);
s2=size(Dat1,2);

ConTest=zeros(s3,s2,s2);
ConRetest=zeros(s3,s2,s2);

for I = 1:s3

ConTest(I,:,:)=corr(Dat1(:,:,I));
ConRetest(I,:,:)=corr(Dat2(:,:,I));

end

ConMean=squeeze(tanh((mean(atanh(ConTest))+mean(atanh(ConRetest)))./2));
AbsMin=min(abs(ConTest),abs(ConRetest));
ConConjunct=(AbsMin==abs(ConTest)).*(ConTest)+(AbsMin==abs(ConRetest)).*(ConRetest);


end