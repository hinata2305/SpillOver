function [CrossLag,CrossLagNoDiag] = crossLag(data1,data2)

s=size(data1,2);

CrossLag=corr(data1(:),data2(:));
data1(logical(eye(s)))=[]; 
data2(logical(eye(s)))=[]; 

CrossLagNoDiag=corr(data1',data2');


end