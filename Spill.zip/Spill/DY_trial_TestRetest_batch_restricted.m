
path=cd
addpath ([path '/github_repo/']);
addpath (path);

%load fMRI_clean.mat
load fMRI_clean_space39.mat
load ReducedCon.mat 

lags = 5;    %lags in the VAR model
nsteps= 10;  %number of steps for computing DY index

useGIRF = 1;

%s=10;
Ext=combined
cons=sum(Ext);
l=size(Clean_SPM_p_1);

    DYtable_storeTest=zeros(l(3),cons,cons,lags);
    From_storeTest=zeros(l(3),cons,lags);
    To_storeTest=zeros(l(3),cons,lags);
    Net_storeTest=zeros(l(3),cons,lags);
    Spill_storeTest=zeros(l(3),cons,lags);

    DYtable_storeRetest=zeros(l(3),cons,cons,lags);
    From_storeRetest=zeros(l(3),cons,lags);
    To_storeRetest=zeros(l(3),cons,lags);
    Net_storeRetest=zeros(l(3),cons,lags);
    Spill_storeRetest=zeros(l(3),cons,lags);


    for k = 1:lags
        nlags=k;
        tic
        for s=1:l(3)

            tic
            y=Clean_SPM_p_1(:,Ext,s);
            %y=timetable(y1,y2,TimeStep=seconds(1));
            nvars = size(y,2);
            Mdl = varm(nvars, nlags);  %sets up a VAR model structure
            %[dyMdl,EstSE1,logL1,E1] = estimate(Mdl, y{idxEst,:});
           [dyMdl,EstSE,logL,E] = estimate(Mdl, y);
            % Compute DY Table
            [DYtable, Spillover, From, To, Net] = computeDYtable(dyMdl, nsteps, useGIRF);  %this computes the spillover indices
            toc

            DYtable_storeTest(s,:,:,k)=DYtable(1:cons,1:cons);
            From_storeTest(s,:,k)=From;
            To_storeTest(s,:,k)=To;
            Net_storeTest(s,:,k)=Net;  %save the net-spillovers
            Spill_storeTest(s,k)=Spillover; %total spillover index, kind of a total dependence measure
            errorT(s,:,:,k)=E;

            y=Clean_SPM_p_2(:,Ext,s);
            %y=verbal_clean_2(:,Ext,s);

            %[dyMdl,EstSE1,logL1,E1] = estimate(Mdl, y{idxEst,:});
            [dyMdl,EstSE,logL,E] = estimate(Mdl, y);

            % Compute DY Table
            [DYtable, Spillover, From, To, Net] = computeDYtable(dyMdl, nsteps, useGIRF);  %this computes the spillover indices

            %name=["Corr AR"; "Corr VAR"; "Corr raw"; "Spillover"];
            %out=[corr(e_y1,e_y2); corr(E1(:,1), E1(:,2)); corr(y1,y2); Spillover];
            %table(name,out);

            DYtable_storeRetest(s,:,:,k)=DYtable(1:cons,1:cons);
            From_storeRetest(s,:,k)=From;
            To_storeRetest(s,:,k)=To;
            Net_storeRetest(s,:,k)=Net;  %save the net-spillovers
            Spill_storeRetest(s,k)=Spillover; %total spillover index, kind of a total dependence measure
            errorR(s,:,:,k)=E;

        end
        toc
    end

save('SpillTR_space39BatchReduced.mat','DYtable_storeTest','From_storeTest','To_storeTest','Net_storeTest','Spill_storeTest','DYtable_storeRetest','From_storeRetest','To_storeRetest','Net_storeRetest','Spill_storeRetest',"errorT","errorR")


