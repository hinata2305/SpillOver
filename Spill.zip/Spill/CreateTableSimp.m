function [tabbie] = CreateTableSimp(saveName,roiName,Dat)


path=cd
s=size(Dat,4);
close all

for k = 1:s

    DatTemp= squeeze((mean(Dat(:,:,:,k))));
    toTemp=(sum(DatTemp,1)-diag(DatTemp)');
    fromTemp=sum(DatTemp,2)-diag(DatTemp)
    %totalNet= toTemp-fromTemp;

    totalSpill=((sum(DatTemp(:))-sum(diag(DatTemp)))./sum(DatTemp(:)))*100

    ALL=[DatTemp fromTemp];
    All=[ALL; toTemp totalSpill ];
    

    tabbie = array2table(round(All,2),'VariableNames',[roiName ;'total received'],'RowNames',[roiName; 'total send' ]);
    saveNameAdress=([path '/OutputStat/' saveName ' VAR ' num2str(k)]);
    writetable(tabbie, saveNameAdress,'WriteRowNames',true);

    PicName=([path '/Image/' saveName 'VAR' num2str(k)]);

    color=[jet(256)];
    h=heatmap(round(All,2),'Colormap',color);
    h.Title = [saveName ' VAR ' num2str(k)] ;
    h.XDisplayLabels=[roiName;'total received'];
    h.YDisplayLabels=[roiName;'total sent'];
    h.FontSize=12;

    pic=gcf
    set(pic,'Position', [0,0,1000,1000]);
    savefig([PicName '.fig']);
    print([PicName], '-dtiff', '-r600')
    close (gcf)
end
