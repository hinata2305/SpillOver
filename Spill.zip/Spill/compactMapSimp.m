function compactMapSimp(taskTest,restTest,taskRetest,restRetest,relMap,tres,name,version,savename)

path=cd

s=size(taskTest,4);


    for numLag=1:s
        [Temp,W]=RelTestAlt(taskTest(:,:,:,numLag),restTest(:,:,:,numLag),taskRetest(:,:,:,numLag),restRetest(:,:,:,numLag),tres);
        relTemp=relMap(:,:,numLag)>0.4;
        MaskedSpill=Temp.*relTemp;
        rows=any(MaskedSpill,2);
        cols=any(MaskedSpill,1);
        %create common space
        ext=(rows+cols')>0;
        allExt(:,numLag)=ext;
        AllW(:,:,numLag)=W;
    end


    if version == 1
    Ext=(sum(allExt,2))>0;
    compact_name=name(Ext);
    matSize=length(compact_name);
    ALLsmall=AllW(Ext,Ext,:);
    maxie_val=max(abs(ALLsmall(:)));
    non_zero =  (abs(ALLsmall))>0;
    minie_val=min(abs(ALLsmall(non_zero)));
    elseif version ==2
    Ext=(sum(allExt,2))>0;
    compact_name=name;
    matSize=length(compact_name);
    ALLsmall=AllW(Ext,Ext,:);
    maxie_val=max(abs(ALLsmall(:)));
    non_zero =  (abs(ALLsmall))>0;
    minie_val=min(abs(ALLsmall(non_zero)));

    end


    for numLag=1:s

        [~,Spill]=RelTestAlt(taskTest(:,:,:,numLag),restTest(:,:,:,numLag),taskRetest(:,:,:,numLag),restRetest(:,:,:,numLag),tres);
        relTempie=relMap(:,:,numLag)>0.4;
        MaskSpill=Spill.*relTempie;

        if version == 1
        compact=MaskSpill(Ext,Ext)
        neg=abs((compact<0).*compact)
        pos=abs((compact>0).*compact)
        elseif version == 2
        compact=MaskSpill;
        neg=abs((compact<0).*compact)
        pos=abs((compact>0).*compact)

        end

        [fig(num2str(numLag))] = figure;
        Gn=digraph(neg',compact_name);
        Nedge_weights=round(Gn.Edges.Weight,2);
        linewidts=1+6*(Nedge_weights-minie_val)/(maxie_val-minie_val)
        %H=plot(Gn,'Layout','circle','LineWidth', linewidts,'EdgeColor','b','ArrowSize',20,'EdgeLabel',Nedge_weights,'EdgeFontSize',12);
        H=plot(Gn,'Layout','circle','LineWidth', linewidts,'EdgeColor','b','ArrowSize',20,'EdgeLabel',[],'EdgeFontSize',12);
        H.NodeFontSize=10
        hold on
        Gp=digraph(pos',compact_name);
        Pedge_weights=round(Gp.Edges.Weight,2)
        linewidts=1+6*(Pedge_weights-minie_val)/(maxie_val-minie_val)
        %H=plot(Gp,'Layout','circle','LineWidth', linewidts,'EdgeColor','r','ArrowSize',20,'EdgeLabel',Pedge_weights,'EdgeFontSize',12);
         H=plot(Gp,'Layout','circle','LineWidth', linewidts,'EdgeColor','r','ArrowSize',20,'EdgeLabel',[],'EdgeFontSize',12);
        H.NodeFontSize=10
        labelnode(H,1:matSize,compact_name);
        
        TitleName=[savename '; Bonferroni corrected ICC>0.4  VAR ' (num2str(numLag)) ]

        title(TitleName)
  
       pic=gcf
       set(pic,'Position', [0,0,900,900])


       tempName=[savename 'bonfICC04VAR' (num2str(numLag)) ]
        savefig([path '/Image/' tempName '.fig'])
        print([path '/Image/' tempName], '-dpdf', '-r600')
     hold off
    end

end


