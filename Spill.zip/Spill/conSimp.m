function [Sig] = conSimp(test,retest)

 [h,ptest]=ttest(test);
 [h,pretest]=ttest(retest);

 tres=0.05/14;
 Sig=(ptest'<tres)&(pretest'<tres);


end