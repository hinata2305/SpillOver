function NetSpillTab(SpacT, SpacR, VerbT, VerbR, RestT, RestR,ICCspac,ICCverb,ICCrest,ICCspacrest,ICCverbrest,ICCspacverb,MNIreduced,roiName)

path=cd

spT=SpacT(:,:,1); 
spR=SpacR(:,:,1);  
veT=VerbT(:,:,1);  
veR=VerbR(:,:,1);  
reT=RestT(:,:,1);
reR=RestR(:,:,1); 

AllNet=([(spT+spR)/2, (veT+veR)/2, (reT+reR)/2, ((spT+spR)/2)-((reT+reR)/2), ((veT+veR)/2)-((reT+reR)/2),((spT+spR)/2)- ((veT+veR)/2)]);
meanNet=reshape(squeeze(mean(AllNet)),14,6)

max(meanNet)
min(meanNet)
mean(meanNet)

AllRel=[ICCspac(:,1),ICCverb(:,1),ICCrest(:,1),ICCspacrest(:,1),ICCverbrest(:,1),ICCspacverb(:,1)];


[Psp]=conSimp(spT,spR);
[Pve]=conSimp(veT,veR);
[Pre]=conSimp(reT,reR);

[Pspre]=conSimp(spT-reT,spR-reR);
[Pvere]=conSimp(veT-reT,veR-reR);
[Pspve]=conSimp(spT-veT,spR-veR);

AllSig=[Psp,Pve,Pre,Pspre,Pvere,Pspve];

RelSig=AllSig.*AllRel>0.4;

allTab=[MNIreduced meanNet AllRel AllSig RelSig]

spillName={'SpaceSpill', 'VerbalSpill', 'RestSpill', 'Space-RestSpill', 'Verbal-RestSpill' 'Space-VerbalSpill'};
relName={'SpaceRel', 'VerbalRel', 'RestRel', 'Space-RestRel', 'Verbal-RestRel' 'Space-VerbalRel'};
sigName={'SpaceSig', 'VerbalSig', 'RestSig', 'Space-RestSig', 'Verbal-RestSig' 'Space-VerbalSig'};
sigrelName={'SpaceSigRel', 'VerbalSigRel', 'RestSigRel', 'Space-RestSigRel', 'Verbal-RestSigRel' 'Space-VerbalSigRel'};

allName=[{'x','y','z'} spillName relName sigName sigrelName];
tabbie = array2table(allTab,'VariableNames',allName,'RowNames',roiName);

    saveNameAdress=([path '/OutputStat/allNetSpillRel']);
    writetable(tabbie, saveNameAdress,'WriteRowNames',true)


end