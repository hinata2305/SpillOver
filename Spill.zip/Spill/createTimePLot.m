function [eventTest, eventRetest] =createTimePLot(DataTest,DataRetest,Ext,roiName,ImageRoi,tempName)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes her


s=size(DataTest)


datTestSmall=DataTest(:,Ext,:);
datRetestSmall=DataRetest(:,Ext,:);


s=size(datTestSmall,3)

% timepoint at which an event starts
startpoint=[1	20	42	62	83	103	122	141	162	183	205	225	244	264	284	303	324	346	367	386	408	428	448	469];
% duration of the event
window=18;


% here we loop trough the subjects
for sub = 1:s
    % here we extract 488 time points * 34 regions (nodes)
    temp1=datTestSmall(:,:,sub);
    temp2=datRetestSmall(:,:,sub);

    % here we loop trough the events
    for event=1:24

        %this is the section of the timecourse we want to extract
        extract=[startpoint(event):startpoint(event)+window]';
        % here we extract the timecourse section of interest (length 19) for 34 regions
        % for a test and retest run
        timesec1=temp1(extract,:);
        timesec2=temp2(extract,:);
        % here we correlate the timecourse sections of interest columnswise
        allTimeTest(event,:,:) = timesec1;
        allTimeRetest(event,:,:) = timesec2;
    end
AllSubTimeTest(sub,:,:)=squeeze(mean(allTimeTest));
AllSubTimeRetest(sub,:,:)=squeeze(mean(allTimeRetest));

end

% extract ifg at timepoint 4 and 8 as well as the summed rest
 ifg_testTime4=AllSubTimeTest(:,8 ,10);
 ifg_retestTime4=AllSubTimeRetest(:,4 ,10);
 ifg_testTime8=AllSubTimeTest(:,8 ,10);
 ifg_retestTime8=AllSubTimeRetest(:,10 ,10);

 temptest=AllSubTimeTest;
 tempretest=AllSubTimeRetest;
 temptest(:,:,10)=[];
 tempretest(:,:,10)=[];

allTest4=mean(temptest(:,4,:),3);
allRetest4=mean(tempretest(:,4,:),3);
allTest8=mean(temptest(:,8,:),3);
allRetest8=mean(tempretest(:,8,:),3);

IFGplotTest=mean(AllSubTimeTest(:,: ,10),1);
IFGplotRetest=mean(AllSubTimeRetest(:,: ,10),1);
allMinusOneT=mean(squeeze(mean(temptest,1))');
allMinusOneR=mean(squeeze(mean(tempretest,1))');

% Here we make timecourse plot
fig=figure
subplot(2,2,[1:2])
plot([IFGplotTest' IFGplotRetest' allMinusOneT' allMinusOneR'],'LineWidth',3)
legend({'IFG test' 'IFG retest' 'AllRoi Test' 'AllRoi Retest'},'FontSize',15)

tr=round(([0 2.5 3.7 6.2 9.9 12.4]/1.24)+5);
tre=[ 4,tr];
eventsE={'', 'encode', 'pause', 'stroop', 'pause', 'recognition', 'end'}

xticks(tre)
xticklabels(eventsE)
set(gca,'FontSize',9)
set(gca,'Ytick',[]);


xline(tre(1),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(2),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(3),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(4),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(5),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(6),'r--','LineWidth',2,'HandleVisibility','off')
xline(tre(7),'r--','LineWidth',2,'HandleVisibility','off')

subplot(2,2,3)
scatter(ifg_testTime4,ifg_retestTime4,'red','filled')
set(gca,'YTick',[])
set(gca,'Xtick',[]);
ylabel('signal t=4 test')
xlabel('signal t=4 retest')

hold on
subplot(2,2,3)
scatter(allTest4,allRetest4,'black','filled')
set(gca,'YTick',[])
set(gca,'Xtick',[]);
hold off
subplot(2,2,4)
scatter(ifg_testTime8,ifg_retestTime8,'red','filled')
set(gca,'YTick',[])
set(gca,'Xtick',[]);

ylabel('signal t=8 test')
xlabel('signal t=8 retest')
hold on
subplot(2,2,4)
scatter(allTest8,allRetest8,'black','filled')
set(gca,'YTick',[])
set(gca,'Xtick',[]);
hold off

set(fig,'Position', [0,0,900,900])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/IFGvsAllTimePlot' tempName '.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/IFGvsAllTimePlot' tempName], '-dtiff', '-r600')

close (fig)

grandMeanEventTest=mean(squeeze(mean(AllSubTimeTest,1))');
eventTest=squeeze(mean(AllSubTimeTest,1));
% plot(eventTest,'LineWidth',3)
% legend(roiName,'FontSize',20)

grandMeanRetest=mean(squeeze(mean(AllSubTimeRetest,1))')
eventRetest=squeeze(mean(AllSubTimeRetest,1));
% plot(eventRetest,'LineWidth',3)
% legend(roiName,'FontSize',20)

sumEvent=(eventTest+eventRetest)/.2
% plot(eventRetest,'LineWidth',3)
% legend(roiName,'FontSize',20)

events={'encode', 'pause', 'stroop', 'pause', 'recognition', 'end'}


fig=figure
meanEvent=(grandMeanEventTest+grandMeanRetest)/2
plot(eventRetest,'LineWidth',3)
legend(roiName,'FontSize',20)

xticks(tr)
xticklabels(events)
set(gca,'YTick',[])
set(gca,'FontSize',14)

hold on
xline(tr(1),'r--','LineWidth',2,'HandleVisibility','off')
xline(tr(2),'r--','LineWidth',2,'HandleVisibility','off')
xline(tr(3),'r--','LineWidth',2,'HandleVisibility','off')
xline(tr(4),'r--','LineWidth',2,'HandleVisibility','off')
xline(tr(5),'r--','LineWidth',2,'HandleVisibility','off')
xline(tr(6),'r--','LineWidth',2,'HandleVisibility','off')
hold off


set(fig,'Position', [0,0,1800,1800])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/AllTimePlot' tempName '.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/AllTimePlot' tempName], '-dtiff', '-r600')

close (fig)

rows=5
cols=4
%pos=[1,2,3,4,5,8,9,12,13,16,17,18,19,20];

pos=[18,9,13,19,17,12,20,16,4,2,3,1,8,5];

fig=figure;

for i=1:14

tempE(:,1)=eventTest(:,i)
tempE(:,2)=eventRetest(:,i)
tempE(:,3)=meanEvent

subplot(rows,cols,pos(i))
plot(tempE,'LineWidth',1)
title(roiName(i),'FontSize',12)
set(gca,'YTick',[])
%xlabel('time')
end

hold on
subplot(5,4,[6 7 10 11 14 15])
imshow(ImageRoi)
hold off
set(fig,'Position', [0,0,900,1200])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/brainTimePlot' tempName '.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/brainTimePlot' tempName], '-dtiff', '-r600')

close (fig)

end