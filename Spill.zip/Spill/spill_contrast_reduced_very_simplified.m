
path=cd
addpath ([path '/ICC/']);
addpath (path);

fwf_region_name = {'Left AIP',
    'Left caudal IPS',
    'Left dACC',
    'Left FEF',
    'Left IFG oper',
    'Left IFG orb tria insula',
    'Left IFS MFG IFG tria',
    'Left IFS MFG',
    'Left LIP',
    'Left preCG1',
    'Left preCG2',
    'Left Precuneus',
    'Left preSMA',
    'Left PSPL',
    'Left rostralMFG',
    'Left SMG',
    'Left STG MTG',
    'Left VIP1',
    'Left VIP2',
    'Right AIP',
    'Right caudal IPS',
    'Right FEF',
    'Right IFG orb insula',
    'Right IFG tria',
    'Right IFJ',
    'Right LIP',
    'Right midMFG',
    'Right precuneus',
    'Right preSMA1',
    'Right preSMA2',
    'Right PSPL',
    'Right rostralMFG',
    'Right VIP1',
    'Right VIP2'};

MniMat=[-34	-38	42
    -28	-66	36
    -2	24	38
    -28	0	58
    -52	12	22
    -36	24	2
    -50	20	28
    -40	16	28
    -40	-44	50
    -42	-4	42
    -52	2	42
    -10	-54	48
    -2	4	62
    -18	-74	42
    -38	52	10
    -58	-38	32
    -60	-50	10
    -22	-64	54
    -32	-54	47
    42	-40	50
    26	-66	38
    34	6	56
    36	28	2
    44	18	4
    48	4	38
    36	-54	48
    50	32	34
    4	-56	54
    8	8	68
    0	18	50
    16	-60	54
    42	46	26
    28	-56	60
    37	-48	35]

inv=MniMat(:,1)*-1;

MniMat(:,1)=inv;

tres=0.05./(34*34);
tresCon=0.05./561;

load SpillTR_space39BatchReduced.mat
spaceTestSpill=DYtable_storeTest;
spaceRetestSpill=DYtable_storeRetest;
NetSpaceTest=Net_storeTest;
NetSpaceRetest=Net_storeRetest;
FromSpaceTest=From_storeTest;
FromSpaceRetest=From_storeRetest;
ToSpaceTest=To_storeTest;
ToSpaceRetest=To_storeRetest;

load SpillTR_verbal39BatchReduced.mat
verbalTestSpill=DYtable_storeTest;
verbalRetestSpill=DYtable_storeRetest;
NetVerbalTest=Net_storeTest;
NetVerbalRetest=Net_storeRetest;
FromVerbalTest=From_storeTest;
FromVerbalRetest=From_storeRetest;
ToVerbalTest=To_storeTest;
ToVerbalRetest=To_storeRetest;

load SpillTR_rest39BatchReduced.mat
restTestSpill=DYtable_storeTest;
restRetestSpill=DYtable_storeRetest;
NetRestTest=Net_storeTest;
NetRestRetest=Net_storeRetest;
FromRestTest=From_storeTest;
FromRestRetest=From_storeRetest;
ToRestTest=To_storeTest;
ToRestRetest=To_storeRetest;

load fMRI_cleanAR1_space39.mat
SpaceTimeTest=CleanAR1_SPM_p_1;
SpaceTimeRetest=CleanAR1_SPM_p_2;

load fMRI_cleanAR1_verbal39.mat
VerbalTimeTest=CleanAR1_SPM_p_1;
VerbalTimeRetest=CleanAR1_SPM_p_2;

load fMRI_cleanAR1_rest39.mat
RestTimeTest=RestCleanAR1_1;
RestTimeRetest=RestCleanAR1_2;

%load roi image
roiPic=imread('allROI.png');
% this is the matrix that reports the rois of the reduced matrix.
load ReducedCon.mat
Ext=combined;
roiName=fwf_region_name(find(Ext));
MNIreduced=MniMat(Ext,:)

extract=tril(true(5),-1);
extract34=tril(true(34),-1);
m=size(spaceTestSpill,2);

% estimate average autcor
Mauto(:,1)=autocorTime(SpaceTimeTest,SpaceTimeRetest);
Mauto(:,2)=autocorTime(VerbalTimeTest,VerbalTimeRetest);
Mauto(:,3)=autocorTime(RestTimeTest,RestTimeRetest);

% write autocorr table
saveNameAdress=([path '/OutputStat/meanAutoCor']);
tabbie = array2table(Mauto,'VariableNames',{'space', 'verbal', 'rest'});
writetable(tabbie, saveNameAdress)

% create time course plots
[TimeVerbT TimeVerbR]=createTimePLot(SpaceTimeTest,SpaceTimeRetest,Ext,roiName,roiPic,'Space');
[TimeSpacT TimeSpacR ]=createTimePLot(VerbalTimeTest,VerbalTimeRetest,Ext,roiName,roiPic,'Verbal');

% Here we esitmate conventional connectivity
[ConSpaceTest, ConSpaceRetest,ConSpaceMean,ConSpaceConjunct] = MainStreamCon(SpaceTimeTest,SpaceTimeRetest);
[ConVerbalTest, ConVerbalRetest,ConVerbalMean,ConVerbalConjunct] = MainStreamCon(VerbalTimeTest,VerbalTimeRetest);
[ConRestTest, ConRestRetest,ConRestMean,ConRestConjunct] = MainStreamCon(RestTimeTest,RestTimeRetest);

% Here we estimate ICC of conventional connectivity
[ICCsp,LBsp,UBsp] = mass_rel(ConSpaceTest,ConSpaceRetest);
[ICCver,LBver,UBver] = mass_rel(ConVerbalTest,ConVerbalRetest);
[ICCres,LBres,UBres] = mass_rel(ConRestTest,ConRestRetest);

[ICCspr,LBspr,UBspr] = mass_rel(ConSpaceTest-ConRestTest,ConSpaceRetest-ConRestRetest);
[ICCverr,LBverr,UBverr] = mass_rel(ConVerbalTest-ConRestTest,ConVerbalRetest-ConRestRetest);
[ICCspverr,LBspverr,UBspverr] = mass_rel(ConSpaceTest-ConVerbalTest,ConSpaceRetest-ConVerbalRetest);

% Here we perform NHST and conjucntion analysis using two sided bonf and
% mask for ICC
[SigSpace,SigSpaceRel,SpaceCohenRel]=RelTestMask(ConSpaceTest,ConSpaceRetest,ICCsp);
[SigVerbal,SigVerbalRel,VerbalCohenRel]=RelTestMask(ConVerbalTest,ConVerbalRetest,ICCver);
[SigRest,SigRestRel,RestCohenRel]=RelTestMask(ConRestTest,ConRestRetest,ICCres);

% Here we test work-rest and conjucntion analysis using two sided bonf and
% mask for ICC
[SigSpaceRest,SigSpaceRestRel]=RelTestMask(ConSpaceTest,ConSpaceRetest,ICCspr,ConRestTest,ConRestRetest);
[SigVerbalRest,SigVerbalRestRel]=RelTestMask(ConVerbalTest,ConVerbalRetest,ICCverr,ConRestTest,ConRestRetest);
[SigSpaceVerbal,SigSpaceVerbalRel]=RelTestMask(ConSpaceTest,ConSpaceRetest,ICCspverr,ConVerbalTest,ConVerbalRetest);

% Number of sig paths for NHST and ICC
sum(abs([SigSpace(extract34), SigVerbal(extract34), SigRest(extract34), SigSpaceRest(extract34), SigVerbalRest(extract34)]))
sum(abs([SigSpaceRel(extract34), SigVerbalRel(extract34), SigRestRel(extract34), SigSpaceRestRel(extract34), SigVerbalRestRel(extract34)]))

% Here the scatter plots resting versus working are created
scatter(ConRestMean(extract34),ConSpaceMean(extract34))
set(gca,'Fontsize',20)
xlabel('Resting State')
ylabel('Spatial Memory')

pic=gcf
set(pic,'Position', [0,0,900,900])

savefig([path '/Image/ScatterRestVSspace.fig'])
print([path '/Image/ScatterRestVSspace'], '-dtiff', '-r600')
close(gcf)

scatter(ConRestMean(extract34),ConVerbalMean(extract34))
set(gca,'Fontsize',20)
xlabel('Resting State')
ylabel('Verbal Memory')

pic=gcf
set(pic,'Position', [0,0,900,900])

savefig([path '/Image/ScatterRestVSverbal.fig'])
print([path '/Image/ScatterRestVSverbal'], '-dtiff', '-r600')
close(gcf)


% this is the rel histogramm
temprel=([ICCsp(extract34) ICCver(extract34) ICCres(extract34) ICCspr(extract34) ICCverr(extract34)]);
mean_rel=tanh(mean(atanh(temprel)));
hist(temprel,20)
pic=gcf
set(pic,'Position', [0,0,900,900])

set(gca,'Fontsize',20)
legend('Space', 'Verbal', 'Rest', 'Space-Rest', 'Verbal-Rest')
legend('Location','northwest')
savefig([path '/Image/rel_hist.fig'])
print([path '/Image/rel_hist'], '-dtiff', '-r600')

close(gcf)


% here we estimate ICC for Spill Over lag 1 to lag 5
for i = 1:5

    %estimate classic ICC rel for resting state
    [r,l,u]=mass_rel(restTestSpill(:,:,:,i), restRetestSpill(:,:,:,i));
    relRest(:,:,i)=r';

    %verbal and space
    [r,l,u]=mass_rel(verbalTestSpill(:,:,:,i), verbalRetestSpill(:,:,:,i));
    relVerbal(:,:,i)=r';
    [r,l,u]=mass_rel(spaceTestSpill(:,:,:,i), spaceRetestSpill(:,:,:,i));
    relSpace(:,:,i)=r';

    %narrow constrast work-rest
    [r,l,u]=mass_rel(verbalTestSpill(:,:,:,i)-restTestSpill(:,:,:,i), verbalRetestSpill(:,:,:,i)-restRetestSpill(:,:,:,i));
    relVerbalRest(:,:,i)=r';
    [r,l,u]=mass_rel(spaceTestSpill(:,:,:,i)-restTestSpill(:,:,:,i), spaceRetestSpill(:,:,:,i)-restRetestSpill(:,:,:,i));
    relSpaceRest(:,:,i)=r';

    %narrow contrast space-verbal
    [r,l,u]=mass_rel(spaceTestSpill(:,:,:,i)-verbalTestSpill(:,:,:,i), spaceRetestSpill(:,:,:,i)-verbalRetestSpill(:,:,:,i));
    relSpaceVerbal(:,:,i)=r';


    %estimate classic ICC rel for resting state
    [r,l,u]=mass_rel(NetRestTest(:,:,i), NetRestRetest(:,:,i));
    relRestNet(:,i)=r';

    %verbal and space
    [r,l,u]=mass_rel(NetVerbalTest(:,:,i), NetVerbalRetest(:,:,i));
    relVerbalNet(:,i)=r';
    [r,l,u]=mass_rel(NetSpaceTest(:,:,i), NetSpaceRetest(:,:,i));
    relSpaceNet(:,i)=r';

    %narrow constrast work-rest
    [r,l,u]=mass_rel(NetVerbalTest(:,:,i)-NetRestTest(:,:,i), NetVerbalRetest(:,:,i)-NetRestRetest(:,:,i));
    relVerbalRestNet(:,i)=r';
    [r,l,u]=mass_rel(NetSpaceTest(:,:,i)-NetRestTest(:,:,i), NetSpaceRetest(:,:,i)-NetRestRetest(:,:,i));
    relSpaceRestNet(:,i)=r';


    [r,l,u]=mass_rel(NetSpaceTest(:,:,i)-NetVerbalTest(:,:,i), NetSpaceRetest(:,:,i)-NetVerbalRetest(:,:,i));
    relSpaceVerbalNet(:,i)=r';

end

% here we estimate correlation between average spill maps across lag 1 to lag 5
for i = 1:5
    for k = (i+1):5

        restSourceT=squeeze(mean(restTestSpill(:,:,:,i)));
        restTargetT=squeeze(mean(restTestSpill(:,:,:,k)));
        [restCrossLagT(k,i),restCrossLagNoDiagT(k,i)] = crossLag( restSourceT, restTargetT);

        restSourceR=squeeze(mean(restRetestSpill(:,:,:,i)));
        restTargetR=squeeze(mean(restRetestSpill(:,:,:,k)));
        [restCrossLagR(k,i),restCrossLagNoDiagR(k,i)] = crossLag( restSourceR, restTargetR);

        verbalSourceT=squeeze(mean(verbalTestSpill(:,:,:,i)));
        verbalTargetT=squeeze(mean(verbalTestSpill(:,:,:,k)));
        [verbalCrossLagT(k,i),verbalCrossLagNoDiagT(k,i)] = crossLag( verbalSourceT, verbalTargetT);

        verbalSourceR=squeeze(mean(verbalRetestSpill(:,:,:,i)));
        verbalTargetR=squeeze(mean(verbalRetestSpill(:,:,:,k)));
        [verbalCrossLagR(k,i),verbalCrossLagNoDiagR(k,i)] = crossLag( verbalSourceR, verbalTargetR);

        spaceSourceT=squeeze(mean(spaceTestSpill(:,:,:,i)));
        spaceTargetT=squeeze(mean(spaceTestSpill(:,:,:,k)));
        [spaceCrossLagT(k,i),spaceCrossLagNoDiagT(k,i)] = crossLag( spaceSourceT, spaceTargetT);

        spaceSourceR=squeeze(mean(spaceRetestSpill(:,:,:,i)));
        spaceTargetR=squeeze(mean(spaceRetestSpill(:,:,:,k)));
        [spaceCrossLagR(k,i),spaceCrossLagNoDiagR(k,i)] = crossLag( spaceSourceR, spaceTargetR);

        [verbalRestCrossLagT(k,i),verbalRestCrossLagNoDiagT(k,i)] = crossLag((verbalSourceT-restSourceT),(verbalTargetT-restTargetT));
        [verbalRestCrossLagR(k,i),verbalRestCrossLagNoDiagR(k,i)] = crossLag((verbalSourceR-restSourceR),(verbalTargetR-restTargetR));
        [spaceRestCrossLagT(k,i),spaceRestCrossLagNoDiagT(k,i)] = crossLag((spaceSourceT-restSourceT),(spaceTargetT-restTargetT));
        [spaceRestCrossLagR(k,i),spaceRestCrossLagNoDiagR(k,i)] = crossLag((spaceSourceR-restSourceR),(spaceTargetR-restTargetR));


        [spaceVerbalCrossLagT(k,i),spaceVerbalCrossLagNoDiagT(k,i)] = crossLag((spaceSourceT-verbalSourceT),(spaceTargetT-verbalTargetT));
        [spaceVerbalCrossLagR(k,i),spaceVerbalCrossLagNoDiagR(k,i)] = crossLag((spaceSourceT-verbalSourceR),(spaceTargetR-verbalTargetR));


    end
end

% get all the cross cor info
restTab=[restCrossLagT restCrossLagR restCrossLagNoDiagT restCrossLagNoDiagR];
verbalTab=[verbalCrossLagT verbalCrossLagR verbalCrossLagNoDiagT verbalCrossLagNoDiagR];
spaceTab=[spaceCrossLagT spaceCrossLagR spaceCrossLagNoDiagT spaceCrossLagNoDiagR];
verbalMinRestTab=[verbalRestCrossLagT verbalRestCrossLagR verbalRestCrossLagNoDiagT verbalRestCrossLagNoDiagR];
spaceMinRestTab=[spaceRestCrossLagT spaceRestCrossLagR spaceRestCrossLagNoDiagT spaceRestCrossLagNoDiagR];
spaceMinVerbal=[spaceVerbalCrossLagT spaceVerbalCrossLagR spaceVerbalCrossLagNoDiagT spaceVerbalCrossLagNoDiagR];

% collect cross cor
allCrosCor=[spaceTab;verbalTab;restTab;spaceMinRestTab;verbalMinRestTab;spaceMinVerbal];

% write autocorr table
saveNameAdress=([path '/OutputStat/CrossAllLags']);
writematrix(allCrosCor, saveNameAdress)

% Here we create scatter plots which show clouds across lagged maps
create3Dscatter(spaceTestSpill-restTestSpill,'SpaceMinusRestTest')

[icc,totSpill] =restingLoad(restTestSpill,restRetestSpill,verbalTestSpill,verbalRetestSpill,spaceTestSpill,spaceRetestSpill);

create3Dscatter(spaceRetestSpill-restRetestSpill,'SpaceMinusRestRetest')
create3Dscatter(verbalTestSpill-restTestSpill,'VerbalMinusRestTest')
create3Dscatter(verbalRetestSpill-restRetestSpill,'VerbalMinusRestRetest')
create3Dscatter(spaceTestSpill-verbalTestSpill,'SpaceMinusVerbalTest')
create3Dscatter(spaceRetestSpill-verbalRetestSpill,'SpaceMinusVerbalRetest')

% Here we scatter the lag1 spillover maps with each other
[noDiagTest,DiagTest,minWithin,maxBetween]=scatter_restwork(spaceTestSpill,verbalTestSpill,restTestSpill,spaceRetestSpill,verbalRetestSpill,restRetestSpill);

% Here we scatter the lag1 maps with the connectivity maps
mRestSpill=(restTestSpill+restRetestSpill)./2;
mVerbalSpill=(verbalTestSpill+verbalRetestSpill)./2;
mSpaceSpill=(spaceTestSpill+spaceRetestSpill)./2;

[CorLower, CorUpper]=scatterSpillCorr(mSpaceSpill,mVerbalSpill,mRestSpill,ConSpaceMean,ConVerbalMean,ConRestMean,Ext);

% here simple spill over tables are created
CreateTableSimp('Resting State',roiName,mRestSpill);
CreateTableSimp('Verbal Working Memory',roiName,mVerbalSpill);
CreateTableSimp('Spatial Working Memory',roiName,mSpaceSpill);

% here the rel of netto spill is reported
AllAR1Net=([relSpaceNet(:,1), relVerbalNet(:,1),...
relRestNet(:,1), relSpaceRestNet(:,1),relVerbalRestNet(:,1),relSpaceVerbalNet(:,1)]);
meanALLR1Net=tanh(mean(atanh(AllAR1Net)));

var={'x', 'y','z', 'Space', 'Verbal', 'Rest', 'Space-Rest', 'Verbal-Rest','Space-Verbal'}
tabbieAllAR1 = array2table([MNIreduced AllAR1Net],'VariableNames',var,'RowNames',roiName);
saveNameAdress=([path '/OutputStat/NetSpillRel']);
writetable(tabbieAllAR1, saveNameAdress,'WriteRowNames',true)

% here the rel of spill is reported
d=m*m;
AllAR1=([reshape(relSpace(:,:,1),d,1), reshape(relVerbal(:,:,1),d,1),...
reshape(relRest(:,:,1),d,1), reshape(relSpaceRest(:,:,1),d,1), reshape(relVerbalRest(:,:,1),d,1)  reshape(relSpaceVerbal(:,:,1),d,1)]);
tanh(mean(atanh(AllAR1)));

meanALLR1=tanh(mean(atanh(AllAR1)));

% This is the rel hist of the spill overs
hist(AllAR1,20)
pic=gcf
set(pic,'Position', [0,0,900,900])
set(gca,'Fontsize',20)
legend('Space', 'Verbal', 'Rest', 'Space-Rest', 'Verbal-Rest')
legend('Location','northwest')
savefig([path '/Image/rel_spill_hist.fig'])
print([path '/Image/rel_spill_hist'], '-dtiff', '-r600')

% here we estimate net spill over significane for lag 1 also for mapping purposes
[PosCoordSpace,PosRegionSpace,NegCoordSpace,NegRegionSpace,CoSpace]=RelTestMaskSpill(NetSpaceTest,NetSpaceRetest,relSpaceNet,MNIreduced);
[PosCoordVerbal,PosRegionVerbal,NegCoordVerbal,NegRegionVerbal,CoVerbal]=RelTestMaskSpill(NetVerbalTest,NetVerbalRetest,relVerbalNet,MNIreduced);
[PosCoordRest,PosRegionRest,NegCoordRest,NegRegionRest,CoRest]=RelTestMaskSpill(NetRestTest,NetRestRetest,relRestNet,MNIreduced);
[PosCoordSpaceRest,PosRegionSpaceRest,NegCoordSpaceRest,NegRegionSpaceRest,CoSpaceRest]=RelTestMaskSpill2(NetSpaceTest,NetSpaceRetest,NetRestTest,NetRestRetest,relSpaceRestNet,MNIreduced);
[PosCoordVerbalRest,PosRegionVerbalRest,NegCoordVerbalRest,NegRegionVerbalRest,CoVerbalRest]=RelTestMaskSpill2(NetVerbalTest,NetVerbalRetest,NetRestTest,NetRestRetest,relVerbalRestNet,MNIreduced);

posRois=[PosRegionSpace PosRegionVerbal PosRegionRest PosRegionSpaceRest PosRegionVerbalRest]
negRois=[NegRegionSpace NegRegionVerbal NegRegionRest NegRegionSpaceRest NegRegionVerbalRest].*-1

tabbie = array2table([MNIreduced posRois+negRois],'VariableNames', {'x','y','z','Space', 'Verbal', 'Rest', 'Space-Rest', 'Verbal-Rest'},'RowNames',roiName)

NetSpillTab(NetSpaceTest,NetSpaceRetest,NetVerbalTest,NetVerbalRetest,NetRestTest,NetRestRetest,...
relSpaceNet,relVerbalNet,relRestNet,relSpaceRestNet,relVerbalRestNet,relSpaceVerbalNet,MNIreduced,roiName)

%here we create digraph images
% this is the contrast working-resting
tres=0.05./(34*34*2);
compactMapSimp(spaceTestSpill,restTestSpill,spaceRetestSpill,restRetestSpill,relSpaceRest,tres,roiName,2,'Spatial WM-Resting State');
compactMapSimp(verbalTestSpill,restTestSpill,verbalRetestSpill,restRetestSpill,relVerbalRest,tres,roiName,2,'Verbal WM-Resting State');
compactMapSimp(spaceTestSpill,verbalTestSpill,spaceRetestSpill,verbalRetestSpill,relSpaceVerbal, tres,roiName,2,'Spatial WM-Verbal WM');

%this is the baseline
[dlpfcS,ifgS]=compactMapSimp3(spaceTestSpill,spaceRetestSpill,relSpace,tres,roiName,'Spatial Working Memory');
[dlpfcV,ifgV]=compactMapSimp3(verbalTestSpill,verbalRetestSpill,relVerbal,tres,roiName,'Verbal Working Memory');
[dlpfcR,ifgR]=compactMapSimp3(restTestSpill,restRetestSpill,relRest,tres,roiName,'Resting State');

[icc,totSpill] =restingLoad(restTestSpill,restRetestSpill,verbalTestSpill,verbalRetestSpill,spaceTestSpill,spaceRetestSpill);





% [fList,pList] = matlab.codetools.requiredFilesAndProducts('spill_contrast_reduced_very_simplified.m');
% 
% 
% newFolder = '/data/backup/Graz/FWF/TRUE_CON/Code/';
% 
% 
% 
% for i = 1:numel(fList)
% 
%     copyfile( fList{i}, newFolder);
% 
% end





















