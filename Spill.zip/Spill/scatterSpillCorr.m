
function [CorLower CorUpper]=scatterSpillCorr(data1, data2, data3,data4, data5, data6,Ext)

close all

s=size(data1,2);
ex14l=tril(true(s),-1);

temp1=squeeze(mean(data1(:,:,:,1)));
temp2=squeeze(mean(data2(:,:,:,1)));
temp3=squeeze(mean(data3(:,:,:,1)));

temp4=data4(Ext,Ext);
temp5=data5(Ext,Ext);
temp6=data6(Ext,Ext);

for h=1:6
    varname=['temp' num2str(h)];
    edat=eval(varname);
    dat_temp(:,h)=edat(ex14l)
end


labelname={'Spatial WM Spill', 'Verbal WM Spill', 'Resting Spill', 'Spatial WM corr', 'Verbal WM corr', 'Resting State corr'}
 
for i = 1:6
     for j = 1:i
         source=dat_temp(:,j)
         target=dat_temp(:,i)
       
         subplot(6,6,(i-1)*6+j);
         scatter(source,target,'black');
         hold on
         xlabel(labelname{j});
         ylabel(labelname{i});
         hold off

     end
end

CorLowerTemp=corr(dat_temp)
CorLower = array2table(CorLowerTemp,'VariableNames',labelname,'RowNames',labelname);
writetable(CorLower, '/data/backup/Graz/FWF/SCHOCK/OutputStat/LowerCorrSpill','WriteRowNames',true)


pic=gcf
set(pic,'Position', [0,0,2000,2000])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillCorrLower.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillCorrLower'], '-dtiff', '-r600')


close all

ex14u=triu(true(s),1)


for h=1:6
    varname=['temp' num2str(h)];
    edat=eval(varname);
    dat_temp(:,h)=edat(ex14u)
end

 
 
for i = 1:6
     for j = 1:i
         source=dat_temp(:,j)
         target=dat_temp(:,i)
       
         subplot(6,6,(i-1)*6+j);
         scatter(source,target,'black');
         hold on
         xlabel(labelname{j});
         ylabel(labelname{i});
         hold off

     end
end


pic=gcf
set(pic,'Position', [0,0,2000,2000])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillCorrUpper.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillCorrUpper'], '-dtiff', '-r600')


CorUpperTemp=corr(dat_temp);

CorUpper = array2table(CorUpperTemp,'VariableNames',labelname,'RowNames',labelname);
writetable(CorUpper, '/data/backup/Graz/FWF/SCHOCK/OutputStat/UpperCorrSpill','WriteRowNames',true)
