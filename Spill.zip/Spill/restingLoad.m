
function[icc,totSpill] =restingLoad(restTestSpill,restRetestSpill,verbalTestSpill,verbalRetestSpill,spaceTestSpill,spaceRetestSpill)


rTS=restTestSpill(:,:,:,1);
rRS=restRetestSpill(:,:,:,1);

% estaimte total spin of test and retest
[RspinT,RspinR]=totalSpin(rTS,rRS);

vTS=verbalTestSpill(:,:,:,1);
vRS=verbalRetestSpill(:,:,:,1);

[VspinT,VspinR]=totalSpin(vTS,vRS);

sTS=spaceTestSpill(:,:,:,1);
sRS=spaceRetestSpill(:,:,:,1);

[SspinT,SspinR]=totalSpin(sTS,sRS);

% estimate test retest rel
[icc.rest, LBrest, UBrest] = ICC([RspinT,RspinR],'A-1');
[icc.ver, LBver, UBver] = ICC([VspinT,VspinR],'A-1');
[icc.spac, LBspac, UBspac] = ICC([SspinT,SspinR],'A-1');
%rel for narrow contrast
[icc.verMinRest, LBverMinR, UBverMinR] = ICC([VspinT-RspinT,VspinR-RspinR],'A-1');
[icc.spacMinRest, LBspacMinR, UBspacMinR] = ICC([SspinT-RspinT,SspinR-RspinR],'A-1');

% grand mean and conjunction
gmRestTotalSpin=mean((RspinT+RspinR)/2);
gmVerbalTotalSpin=mean((VspinT+VspinR)/2);
gmSpatialTotalSpin=mean((SspinT+SspinR)/2);

[h,pTest]=ttest(VspinT, RspinT);
[h,pRetest]=ttest(VspinR, RspinR);
totSpill.conjunctVerVsRest=max(pTest,pRetest);

[h,pTest]=ttest(SspinT, RspinT);
[h,pRetest]=ttest(SspinR, RspinR);
totSpill.conjunctSpacVsRest=max(pTest,pRetest);

%relativ spillover
totSpill.relativLoadVer=((gmVerbalTotalSpin-gmRestTotalSpin)/gmRestTotalSpin)*100;
totSpill.relativLoadSpac=((gmSpatialTotalSpin-gmRestTotalSpin)/gmRestTotalSpin)*100;
%
totSpill.restingLoadVer=gmRestTotalSpin/(gmVerbalTotalSpin-gmRestTotalSpin);
totSpill.restingLoadSpac=gmRestTotalSpin/(gmSpatialTotalSpin-gmRestTotalSpin);