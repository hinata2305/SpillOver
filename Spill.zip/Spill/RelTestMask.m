
function [CorMat,Masked,CohenD] = RelTestMask(Dat1Test,Dat1Retest,ICCmap,Dat2Test,Dat2Retest)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here




if nargin == 5

s=size(Dat1Test,2);
tres=0.05./((s.*s)-s)

[~,Testp,~,TestStat]=ttest(atanh(Dat1Test),atanh(Dat2Test));
[~,Retestp,~,RetestStat]=ttest(atanh(Dat1Retest),atanh(Dat2Retest));

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=(squeeze(Testp<tres))&(squeeze(Retestp<tres));
CorMat=(bonf.*signi)./2;

Masked=CorMat.*(ICCmap>0.4);


elseif nargin == 3

samp=size(Dat1Test,1);   
s=size(Dat1Test,2);
tres=0.05./((s.*s)-s);

[~,Testp,~,TestStat]=ttest(atanh(Dat1Test));
[~,Retestp,~,RetestStat]=ttest(atanh(Dat1Retest));

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=(squeeze(Testp<tres))&(squeeze(Retestp<tres));
CorMat=(bonf.*signi)./2;
Masked=CorMat.*(ICCmap>0.4);

CohenD=((squeeze(min(TestStat.tstat, RetestStat.tstat)))/sqrt(samp)).*(ICCmap>0.4);



end

end