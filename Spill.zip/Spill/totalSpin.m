


function [TotalSpillTest,TotalSpillRetest]=totalSpin(test,retest)


s=size(test,1);

for i=1:s

Mtest=squeeze(test(i,:,:));
diagonal=diag(Mtest);
TotalSpillTest(i)=((sum(sum(Mtest)))-sum(diagonal))./sum(sum(Mtest))*100;

Mretest=squeeze(retest(i,:,:));
diagonal=diag(Mretest);
TotalSpillRetest(i)=((sum(sum(Mretest)))-sum(diagonal))./sum(sum(Mretest))*100;

end


TotalSpillTest=TotalSpillTest';

TotalSpillRetest=TotalSpillRetest';


end