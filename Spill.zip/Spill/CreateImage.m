function [LessMat,MoreMat] = CreateImage(Mat)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

s=size(Mat);
Mat(1:s+1:end)=0;

MatN=(Mat<0);
MatP=(Mat>0);
LessMat=(MatN+MatN')>0;
MoreMat=(MatP+MatP')>0;



end





















% 
% Temp= (tril(Mat));
% indNl=Temp==-1;
% spaceNL=indNl+indNl';
% 
% Temp= (triu(Mat));
% indNu=Temp==-1;
% spaceNU=indNu+indNu';
% 
% LessMat=(spaceNL+spaceNU)>0;
% 
% Temp= (tril(Mat));
% indPl=Temp==1;
% spacePL=indPl+indPl';
% 
% Temp= (triu(Mat));
% indPu=Temp==1;
% spacePU=indPu+indPu';
% 
% MoreMat=(spacePL+spacePU)>0;

