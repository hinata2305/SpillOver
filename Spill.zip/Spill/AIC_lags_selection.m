path=cd
addpath ([path '/github_repo/']);
addpath (path);

load fMRI_clean_rest39.mat
load ReducedCon.mat

Clean_SPM_p_1=RestClean1(:,combined,:);
Clean_SPM_p_2=RestClean2(:,combined,:);

NumSub=size(Clean_SPM_p_1,3);

min_aic=zeros(NumSub,1);
min_bic=zeros(NumSub,1);

aicTest=zeros(NumSub,5);
bicTest=zeros(NumSub,5);

parfor s=1:NumSub  %loop over the individuals

    %y=Clean_SPM_p_1(:,1:34,s);  %select which data you want to use (test or
    %re-test) - and we use only 14 regions!!!
    y1=Clean_SPM_p_1(:,:,s);
    y2=Clean_SPM_p_2(:,:,s);

    %create timetable of the data
    T=length(y1);
    nvars = size(y1,2);
    y1=timetable(y1,TimeStep=seconds(1));
    y2=timetable(y2,TimeStep=seconds(1));

    idxPre=1:5;
    idxEst= 6:T;

    %select lag length based on AIC and BIC

    for l=1:5  %try 1 to 5 lags

        Mdl = varm(nvars, l);
        [EstMdl1,EstSE1,logL1,E1] = estimate(Mdl, y1{idxEst ,:},'Y0',y1{idxPre,:});
        results = summarize(EstMdl1);
        aicTest(s,l)=results.AIC;
        bicTest(s,l)=results.BIC;

        [EstMdl1,EstSE1,logL1,E1] = estimate(Mdl, y2{idxEst ,:},'Y0',y2{idxPre,:});
        results = summarize(EstMdl1);
        aicRetest(s,l)=results.AIC;
        bicRetest(s,l)=results.BIC;

    end

end

for s=1:NumSub

    [~, min_aicT(s)]=min(aicTest(s,:));
    [~, min_bicT(s)]=min(bicTest(s,:));

    [~, min_aicR(s)]=min(aicRetest(s,:));
    [~, min_bicR(s)]=min(bicRetest(s,:));

end


saveNameAdress=([path '/OutputStat/FitStatRest.mat']);
save(saveNameAdress,'aicTest','aicRetest','bicTest','bicRetest','min_aicT','min_aicR','min_bicT','min_aicR')

