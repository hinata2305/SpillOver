
function [PosCoord,PosRegionEx,NegCoord,NegRegionEx,signi] = RelTestMaskSpill(DatTest,DatRetest,ICCmap,coord)

tres=0.05./34

Dat1Test=DatTest(:,:,1);
Dat1Retest=DatRetest(:,:,1);

[~,Testp,~,TestStat]=ttest(Dat1Test);
[~,Retestp,~,RetestStat]=ttest(Dat1Retest);

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=(squeeze(Testp<tres))&(squeeze(Retestp<tres));
CorMat=(bonf.*signi)./2;
Masked=CorMat'.*(ICCmap(:,1)>0.4);

NegRegionEx=(Masked<0);
PosRegionEx=(Masked>0);

NegCoord=coord(Masked<0,:);
PosCoord=coord(Masked>0,:);

end

