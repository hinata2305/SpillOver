function [all]=autocorTime(dataTest,dataRetest)

s=size(dataTest,3);
roi=size(dataTest,2);

for sub = 1:s

    % here we extract 488 time points * 34 regions (nodes)
    temp1=dataTest(:,:,sub);
    temp2=dataRetest(:,:,sub);

    % here we loop trough the events
    for roi=1:34

        timesec1=temp1(:,roi);
        timesec2=temp2(:,roi);
        % here we correlate the timecourse sections of interest columnswise
        ctest(sub,:,roi) = xcorr(timesec1,10,'normalized');
        cretest(sub,:,roi) = xcorr(timesec2,10,'normalized');

    end

end

testie=squeeze(mean(atanh(ctest)));
retestie=squeeze(mean(atanh(cretest)));
all=tanh((mean(testie,2)+mean(retestie,2))/2);