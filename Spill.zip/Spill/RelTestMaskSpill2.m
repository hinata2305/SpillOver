
function [PosCoordMasked,PosRegionEx,NegCoordMasked,NegRegionEx,signi] = RelTestMaskSpill2(DatATest,DatARetest,DatBTest,DatBRetest,ICCmap,coord)

tres=0.05./34

Dat1Test=DatATest(:,:,1);
Dat1Retest=DatARetest(:,:,1);
Dat2Test=DatBTest(:,:,1);
Dat2Retest=DatBRetest(:,:,1);

[~,Testp,~,TestStat]=ttest(Dat1Test,Dat2Test);
[~,Retestp,~,RetestStat]=ttest(Dat1Retest,Dat2Retest);

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=(squeeze(Testp<tres))&(squeeze(Retestp<tres));
CorMat=(bonf.*signi)./2;
Masked=CorMat'.*(ICCmap(:,1)>0.4);

NegRegionEx=(Masked<0);
PosRegionEx=(Masked>0);

NegCoordMasked=coord(Masked<0,:);
PosCoordMasked=coord(Masked>0,:);

end

