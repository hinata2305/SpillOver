function [dlpfc ifg]=compactMapSimp3(taskTest,taskRetest,relMap,tres,name,savename)



path=cd

spillTres=5;

s=size(taskTest,4);
poi=size(taskTest,2);

DLPFC_l=zeros(poi,poi);
IFG_r=zeros(poi,poi);

for numLag=1:s
    [Temp,W]=RelTestSingle(taskTest(:,:,:,numLag),taskRetest(:,:,:,numLag),tres);
    relTemp=relMap(:,:,numLag)>0.6;
    MaskedSpill=Temp.*relTemp;
    rows=any(MaskedSpill,2);
    cols=any(MaskedSpill,1);
    %create common space
    ext=(rows+cols')>0;
    allExt(:,numLag)=ext;
    AllW(:,:,numLag)=W;
end

Ext=(sum(allExt,2))>0;
compact_name=name;
matSize=length(compact_name);
ALLsmall=AllW(Ext,Ext,:);
maxie_val=max(abs(ALLsmall(:)));
minie_val=min(abs(ALLsmall(:)));

for numLag=1:s

    [~,Spill]=RelTestSingle(taskTest(:,:,:,numLag),taskRetest(:,:,:,numLag),tres);
    relTempie=relMap(:,:,numLag)>0.6;
    MaskSpill=Spill.*relTempie;

    DLPFC_l(:,3)=MaskSpill(:,3);
    DLPFC_l(3,:) = MaskSpill(3,:);
    DiagDLPFC=(MaskSpill(:,3)>spillTres)+((MaskSpill(3,:)>spillTres)');

    IFG_r(:,10)=MaskSpill(:,10);
    IFG_r(10,:) = MaskSpill(10,:);
    DiagIFG=(MaskSpill(:,10)>spillTres)+((MaskSpill(10,:)>spillTres)');


    IFG_f=(IFG_r>spillTres).*IFG_r;
    DLPFC_f=(DLPFC_l>spillTres).*DLPFC_l;
    DiagTot=(diag((DiagDLPFC+DiagIFG)>0)).*MaskSpill;

    Diag_f=(DiagTot>spillTres).*DiagTot;

    [fig(num2str(numLag))] = figure;
    Gn=digraph(DLPFC_f',compact_name);
    Nedge_weights=round(Gn.Edges.Weight,2)
    linewidts=1+15*(Nedge_weights-minie_val)/(maxie_val-minie_val)
    %H=plot(Gn,'Layout','circle','LineWidth', linewidts,'EdgeColor','g','ArrowSize',20,'EdgeLabel',Nedge_weights,'EdgeFontSize',12);
    H=plot(Gn,'Layout','circle','LineWidth', linewidts,'EdgeColor','g','ArrowSize',20,'EdgeLabel',[],'EdgeFontSize',12);
    H.NodeFontSize=10

    hold on
    Gp=digraph(IFG_f',compact_name);
    Pedge_weights=round(Gp.Edges.Weight,2)
    linewidts=1+15*(Pedge_weights-minie_val)/(maxie_val-minie_val)
    %H=plot(Gp,'Layout','circle','LineWidth', linewidts,'EdgeColor','m','ArrowSize',20,'EdgeLabel',Pedge_weights,'EdgeFontSize',12);
    H=plot(Gp,'Layout','circle','LineWidth', linewidts,'EdgeColor','m','ArrowSize',20,'EdgeLabel',[],'EdgeFontSize',12);
    H.NodeFontSize=10
  

    hold on
    Gr=digraph(Diag_f',compact_name);
    Sedge_weights=round(Gr.Edges.Weight,2)
    linewidts=1+15*(Sedge_weights-minie_val)/(maxie_val-minie_val)
    %H=plot(Gr,'Layout','circle','LineWidth', linewidts,'EdgeColor','y','ArrowSize',20,'EdgeLabel',Sedge_weights,'EdgeFontSize',12);
    H=plot(Gr,'Layout','circle','LineWidth', linewidts,'EdgeColor','y','ArrowSize',20,'EdgeLabel',[],'EdgeFontSize',12);
   
    H.NodeFontSize=10
    
    labelnode(H,1:matSize,compact_name);

    TitleName=[savename ' Spillover>5 ICC>0.6 VAR ' (num2str(numLag)) ]
    title(TitleName)

    tempName=[savename 'Spill05ICC06VAR' (num2str(numLag)) ]
    pic=gcf
    set(pic,'Position', [0,0,900,900])

    savefig([path '/Image/' tempName '.fig'])
    print([path '/Image/' tempName], '-dpdf', '-r600')
    hold off

    if numLag==1
        dlpfc=DLPFC_f;
        ifg= IFG_f;

    else
        %nothing here
    end


end

end


