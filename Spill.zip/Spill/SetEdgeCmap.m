function SetEdgeCmap( EdgeCmap )
colormap(EdgeCmap);
VisCon_UpdateEdges('Alt');
end

