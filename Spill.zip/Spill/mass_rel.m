function [r,LB,UB] = mass_rel(test,retest)



dim=ndims(test);

if dim==2



    roinum=size(test,2);


    for i = 1:roinum

        [r(i), LB(i), UB(i)] = ICC([test(:,i) retest(:,i)],'A-1');


    end



    
else
    roinum=size(test,2);

    for i = 1:roinum
        for k = 1:roinum

            [r(i,k), LB(i,k), UB(i,k)] = ICC([test(:,i,k) retest(:,i,k)],'A-1');


        end

    end




end


end