
function [CorMat] = ConjTestRel(Dat1Test,Dat2Test,Dat1Retest,Dat2Retest,tres,ICCmap)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[~,Testp,~,TestStat]=ttest(Dat1Test, Dat2Test);
[~,Retestp,~,RetestStat]=ttest(Dat1Retest,Dat2Retest);

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=(squeeze(Testp<tres))&(squeeze(Retestp)<tres);
CorMat=((bonf.*signi)./2).*(ICCmap>0.4);



end