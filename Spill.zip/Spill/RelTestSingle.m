
function [bonf,Weighted] = RelTestSingle(Dat1Test,Dat1Retest,tres)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


[~,Testp]=ttest(Dat1Test);
[~,Retestp]=ttest(Dat1Retest);

bonf=(squeeze(Testp<tres)+squeeze(Retestp<tres))>1;
Weighted =squeeze(mean((Dat1Test+Dat1Retest)./2)).*bonf;



end