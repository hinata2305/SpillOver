function [fig] = create3Dscatter(dat,tempName)
path=cd

fig=figure

 for i = 1:5
     for j = 1:i
         source=squeeze(mean(dat(:,:,:,j)))
         target=squeeze(mean(dat(:,:,:,i)))
         subplot(5,5,(i-1)*5+j);
         scatter(source,target);
         hold on
         xlabel(['VAR(' num2str(j) ')']);
         ylabel(['VAR(' num2str(i) ')']);
         hold off

     end
 end

       pic=gcf

        annotation("textbox",[0.45 0.8 0.1 0.1],'string', tempName,'FitBoxToText','on' )
       set(pic,'Position', [0,0,900,900])
        savefig([path '/Image/scatter' tempName '.fig'])
        print([path '/Image/scatter' tempName], '-dtiff', '-r600')


end

