
function [CorMat,Weighted] = RelTestAlt(Dat1Test,Dat2Test,Dat1Retest,Dat2Retest,tres)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


s=size(Dat1Test,2);

[~,Testp,~,TestStat]=ttest(Dat1Test, Dat2Test);
[~,Retestp,~,RetestStat]=ttest(Dat1Retest,Dat2Retest);

signi=squeeze(sign(TestStat.tstat))+squeeze(sign(RetestStat.tstat));
bonf=squeeze((Testp(:,1:s,1:s))<tres)&squeeze((Retestp(:,1:s,1:s))<tres);
CorMat=(bonf.*signi)./2;

Weighted =squeeze(((mean((Dat1Test+Dat1Retest)./2))-(mean((Dat2Test+Dat2Retest)./2)))).*(abs(CorMat));



end