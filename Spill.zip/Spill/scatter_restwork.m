function [nonDiagCor,DiagCor,maxBetween,minWithin]=scatter_restwork(data1, data2, data3,data4, data5, data6)

temp=data3(:,:,:,1);
n=size(temp);
s=n(3);

temp1=squeeze(mean(data1(:,:,:,1)));
s=size(temp1);
diag1=diag(temp1);
temp1(logical(eye(s)))=[]; 

temp2=squeeze(mean(data2(:,:,:,1)));
diag2=diag(temp2);
temp2(logical(eye(s)))=[]; 

temp3=squeeze(mean(data3(:,:,:,1)));
diag3=diag(temp3);
temp3(logical(eye(s)))=[]; 

temp4=squeeze(mean(data4(:,:,:,1)));
diag4=diag(temp4);
temp4(logical(eye(s)))=[]; 

temp5=squeeze(mean(data5(:,:,:,1)));
diag5=diag(temp5);
temp5(logical(eye(s)))=[]; 

temp6=squeeze(mean(data6(:,:,:,1)));
diag6=diag(temp6);
temp6(logical(eye(s)))=[]; 

dat_temp=[temp1', temp2', temp3' temp4' temp5' temp6'];
maxBetween=max(max(dat_temp));
nonDiagCor=corr(dat_temp);

labelname={'Spatial WM Test', 'Verbal WM Test', 'Resting State Test', 'Spatial WM Retest', 'Verbal WM Retest', 'Resting State Retest'};
 
 
for i = 1:6
     for j = 1:i
         source=dat_temp(:,j)
         target=dat_temp(:,i)
       
         subplot(6,6,(i-1)*6+j);
         scatter(source,target,'black');
         hold on
         xlabel(labelname{j});
         ylabel(labelname{i});
         hold off

     end
end

pic=gcf
set(pic,'Position', [0,0,2000,2000])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestWork.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestWork'], '-dtiff', '-r600')



        diag_temp=[diag1, diag2, diag3 diag4 diag5 diag6];
        minWithin=min(min(diag_temp));
        DiagCor=corr(diag_temp);
  
        
for i = 1:6
     for j = 1:i

         source=diag_temp(:,j);
         target=diag_temp(:,i);
       
         subplot(6,6,(i-1)*6+j);
         scatter(source,target,'black');
         hold on
         xlabel(labelname{j});
         ylabel(labelname{i});
         hold off

     end
end


pic=gcf
set(pic,'Position', [0,0,2000,2000])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestWorkDiag.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestWorkDiag'], '-dtiff', '-r600')

close all;

dat_sum=(dat_temp(:,1:3)+dat_temp(:,4:6))./2
diag_sum=(diag_temp(:,1:3)+diag_temp(:,4:6))./2
both=[dat_sum; diag_sum]

x=both(:,3)
y=both(:,1)
mdl=fitlm(x,y)
txt={['Intercept:' num2str(mdl.Coefficients.Estimate(1))]...
['Slope:' num2str(mdl.Coefficients.Estimate(2))]...
['R-squared:' num2str(mdl.Rsquared.Ordinary)]}
scatter(dat_sum(:,3),dat_sum(:,1),'black','filled')
hold on
scatter(diag_sum(:,3),diag_sum(:,1),'magenta','filled')
%plot(x,mdl.Coefficients.Estimate(2)*x+mdl.Coefficients.Estimate(1),'r')
text(10,50,txt,'Color', 'red','FontSize',14)
xlabel('resting state','FontSize',14)
ylabel('spatial working memory','FontSize',14)
hold off

pic=gcf
set(pic,'Position', [0,0,900,900])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestSpaceBI.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestSpaceBI'], '-dtiff', '-r600')

close all;

x=both(:,3)
y=both(:,2)
mdl=fitlm(x,y)
txt={['Intercept:' num2str(mdl.Coefficients.Estimate(1))]...
['Slope:' num2str(mdl.Coefficients.Estimate(2))]...
['R-squared:' num2str(mdl.Rsquared.Ordinary)]}
scatter(dat_sum(:,3),dat_sum(:,2),'black','filled')
hold on
scatter(diag_sum(:,3),diag_sum(:,2),'magenta','filled')
%plot(x,mdl.Coefficients.Estimate(2)*x+mdl.Coefficients.Estimate(1),'r')
text(10,50,txt,'Color', 'red','FontSize',14)
xlabel('resting state','FontSize',14)
ylabel('verbal working memory','FontSize',14)

hold off

pic=gcf
set(pic,'Position', [0,0,900,900])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestVerbalBI.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillRestVerbalBI'], '-dtiff', '-r600')

close all

x=both(:,2)
y=both(:,1)
mdl=fitlm(x,y)
txt={['Intercept:' num2str(mdl.Coefficients.Estimate(1))]...
['Slope:' num2str(mdl.Coefficients.Estimate(2))]...
['R-squared:' num2str(mdl.Rsquared.Ordinary)]}
scatter(dat_sum(:,2),dat_sum(:,1),'black','filled')
hold on
scatter(diag_sum(:,2),diag_sum(:,1),'magenta','filled')
%plot(x,mdl.Coefficients.Estimate(2)*x+mdl.Coefficients.Estimate(1),'r')
text(10,50,txt,'Color', 'red','FontSize',14)
xlabel('verbal working memory','FontSize',14)
ylabel('spatial working memory','FontSize',14)
hold off

pic=gcf
set(pic,'Position', [0,0,900,900])
savefig(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillVerbalSpaceBI.fig'])
print(['/data/backup/Graz/FWF/SCHOCK/Image/scatterSpillVerbalSpaceBI'], '-dtiff', '-r600')


end







